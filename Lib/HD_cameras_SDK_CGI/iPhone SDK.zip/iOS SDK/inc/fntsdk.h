#ifndef	__FCSDK_H
#define __FCSDK_H


/*#define USE_FOSCAM_UDT
#define USE_FOSCAM_UDP
#define USE_FOSCAM_TCP
#define USE_FOSCAM_MJPEG*/



#include "types.h"




//////////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
extern "C" {
#endif
	/**
	 *	fs_init:Init environment of api
	**/
	FCNET_SDK int WINAPI fs_init();

	/**
	 *	fs_init:Deinit environment of api
	**/
	FCNET_SDK void WINAPI fs_deinit();
	
	/**
	 *	fs_search_devices: Search cameras in LAN
	 *  Param
	 *       msg_cb		: Callback function of fs_search_devices, it will be called if we received a response msg,
						  it means this callback will be called multi times during the search process.
	 *       userdata	: Parameter will be passed into msg_cb
	 *       searchTime	: Search timeout time.
	 *       reserve	: Not in use, MUST be zero.
	 *  Return
	 *		 Handle of search function.
	 *       
	**/
	FCNET_SDK HFSSEARCH WINAPI fs_search_devices(SEARCH_CB msg_cb, void *userdata, int searchTime, int reserve);


	/**
	 *	fs_close_search: Terminate search process
	 *  Param
	 *       search		: Handle of search function returned by fs_search_devices
	 *	Return
	 *       None
	**/
	FCNET_SDK void WINAPI fs_close_search(HFSSEARCH search);

	
	/**
	 *	fs_net_open: Init network environment and connect to camera
	 *	Param
	 *      type		: The stream type, can be DT_MJPEG/DT_UDT_TCP/DT_UDT_UDP
	 *                    DT_MJPEG : Connect to MJPEG camera
	 *					  DT_UDT_TCP : Connect to H264 camera's main stream
	 *                    DT_UDT_UDP : Connect to H264 camera's sub stream(Resolution is small and bit rate it low)
	 *      url			: Not in use, MUST be NULL
	 *      netParam	: Net param, for detail, see LPNETPARAM
	 *      open_opt	: MUST be zero
	 *      open_type	: 0x00000000 : We will not reconnect to camera when disconnected
	                      0x00010000 : We will reconnect to camera when disconnected
	 *      fmt_video	: Not in use now
	 *      msg_cb		: Status callback, ie. user name error
	 *      frame_cbf	: Video and audio stream callback
	 *      userdata	: Parameter will be passed into msg_cb and frame_cbf
	 *   Return
	 *      Handle of net operation
	 **/
	FCNET_SDK HFSCLIENT WINAPI fs_net_open(int type, const char *url, LPNETPARAM netParam, int open_opt, int open_type,
		MEDIA_FORMAT_T fmt_video, MSG_CB2 msg_cb, FRAME_CB frame_cbf, void *userdata);


	/**
	 *	fs_net_open: Disconnect to camera and deinit network environment 
	 *	
	 **/
	FCNET_SDK void WINAPI fs_net_close(HFSCLIENT dev);


	/**
	 *	fs_net_open: Send command to camera
	 *	Param
	 *       dev		: Handle of net operation
	 *       command	: Control command 
	 *       lParam	    : lParam of command
	 *       wParam     : wParam of command
	 *  Return
	 *       None
	 **/
	FCNET_SDK void WINAPI fs_net_setcommand(HFSCLIENT dev, int command, LPARAM lParam/* = NULL*/, WPARAM wParam/* = NULL*/);

#ifdef __cplusplus
}
#endif

#endif
