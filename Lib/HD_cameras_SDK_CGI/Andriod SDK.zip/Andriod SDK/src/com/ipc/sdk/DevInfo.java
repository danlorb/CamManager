package com.ipc.sdk;

public class DevInfo {
	public int devType; //0=MJ 1=H264
	public String devName;
	public String ip;
	public String mac;
	public int webPort;
	public int mediaPort;
	public String uid;
	public int reserve1;
	public int reserve2;
	public int reserve3;
	public int reserve4;
}
