/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.ipc.sdk;

import android.util.Log;

import com.ipc.sdk.AVStreamData;
import com.ipc.sdk.StatusListener;


public class FSApi 
{	
	private static StatusListener mListener;
	
	private static void StatusCbk(int statusID, int reserve1, int reserve2, int reserve3, int reserve4)
	{
		//Log.d("FSApi", "StatusCbk statusID:"+statusID );
		
		mListener.OnStatusCbk( statusID, reserve1, reserve2, reserve3, reserve4 );
	}
	
	public static void setStatusListener(StatusListener listener)
	{
		mListener = listener;
	}
    
    /*
     * Start search cameras in your LAN 
     */
    public static native int searchDev();
    public static native DevInfo[] getDevList( DevInfo dev );
    
    
    /*
     * Login to camera.
     * This function will return immediately, login result will be found in StatusCbk
     */
	public static native int usrLogIn(int devType, String ip, String userName, String password, int streamType, int webPort, int mediaPort, String uid);
	
	
    public static native int  usrLogOut();
    
    
    public static native int  ptzMoveUp();
    public static native int  ptzMoveDown();
    public static native int  ptzMoveLeft();
    public static native int  ptzMoveRight();
    public static native int  ptzMoveTopLeft();
    public static native int  ptzMoveTopRight();
    public static native int  ptzMoveBottomLeft();
    public static native int  ptzMoveBottomRight();
    public static native int  ptzStopRun();
    
    
    public static native int startVideoStream();
    public static native int getVideoStreamData(AVStreamData streamData);
    public static native int stopVideoStream();
    public static native int startAudioStream();
    public static native int getAudioStreamData(AVStreamData streamData);
    public static native int stopAudioStream();
    
    public static native int startTalk();
    public static native int sendTalkFrame(byte[] frame, int frameLen);
    public static native int stopTalk();
    
    public static native int snapPic(String saveDir);
   
    static {
    	try{
    		System.loadLibrary("IOTCAPIs"); 
    	}catch(UnsatisfiedLinkError ule){
    		Log.d("moon", ule.getMessage() );
    	}
    	try{
    		System.loadLibrary("RDTAPIs"); 
    	}catch(UnsatisfiedLinkError ule){
    		Log.d("moon", ule.getMessage() );
    	}
    	try{
    		System.loadLibrary("FSApi"); 
    	}catch(UnsatisfiedLinkError ule){
    		Log.d("moon", ule.getMessage() );
    	}
    }

}
