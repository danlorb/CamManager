﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace FOSCAMViewer
{
    public partial class Form1 : Form
    {
        private Thread _cameraThread;
        private Thread _commandThread;
        private WebClient wc;
        private HttpWebRequest req;
        private WebResponse res;
        private Stream stream;
        private string cameraUrl = "http://{0}/snapshot.cgi?user={1}&pwd={2}";
        private string commandUrl = "http://{0}/decoder_control.cgi?user={1}&pwd={2}&command={3}";
        private string controlUrl = "http://{0}/camera_control.cgi?user={1}&pwd={2}&param={3}&value={4}";

        public Form1()
        {
            InitializeComponent();

            Control.CheckForIllegalCrossThreadCalls = false;
        }

        #region Form Handlers
        private void btnRun_Click(object sender, EventArgs e)
        {
            if (btnRun.Text.Equals("Start"))
            {
                if (_cameraThread == null)
                    _cameraThread = new Thread(new ThreadStart(Run));

                _cameraThread.Start();
                btnRun.Text = "Stop";
            }
            else
            {
                btnRun.Text = "Start";
                _cameraThread.Abort();
                _cameraThread = null;
            }
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            SendCommand(commandUrl, "0");
            Thread.Sleep(250);
            SendCommand(commandUrl, "1");
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            SendCommand(commandUrl, "6");
            Thread.Sleep(250);
            SendCommand(commandUrl, "1");
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            SendCommand(commandUrl, "4");
            Thread.Sleep(250);
            SendCommand(commandUrl, "1");
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            SendCommand(commandUrl, "2");
            Thread.Sleep(250);
            SendCommand(commandUrl, "1");
        }

        private void btnUpDown_Click(object sender, EventArgs e)
        {
            if (btnUpDown.Text.Equals("Up / Down"))
            {
                btnUpDown.Text = "Stop";
                SendCommand(commandUrl, "26");
            }
            else
            {
                btnUpDown.Text = "Up / Down";
                SendCommand(commandUrl, "27");
            }
        }

        private void btnLeftRight_Click(object sender, EventArgs e)
        {
            if (btnLeftRight.Text.Equals("Left / Right"))
            {
                btnLeftRight.Text = "Stop";
                SendCommand(commandUrl, "28");
            }
            else
            {
                btnLeftRight.Text = "Left / Right";
                SendCommand(commandUrl, "29");
            }
        }

        private void btnIR_Click(object sender, EventArgs e)
        {
            if (btnIR.Text.Equals("IR On"))
            {
                btnIR.Text = "IR Off";
                SendCommand(commandUrl, "95");
            }
            else
            {
                btnIR.Text = "IR On";
                SendCommand(commandUrl, "94");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_cameraThread != null)
            {
                _cameraThread.Abort();
                _cameraThread = null;
            }
        }

        private void txtBrightness_ValueChanged(object sender, EventArgs e)
        {
            SendCommand(controlUrl, "1", (txtBrightness.Value * 16).ToString());
        }

        private void txtContrast_ValueChanged(object sender, EventArgs e)
        {
            SendCommand(controlUrl, "2", txtContrast.Value.ToString());
        }
        #endregion

        #region Private Methods
        private void Run()
        {
            while (btnRun.Text.Equals("Stop"))
            {
                try
                {
                    cameraUrl = String.Format(cameraUrl, txtHost.Text, txtUsername.Text, txtPassword.Text);
                    req = (HttpWebRequest)HttpWebRequest.Create(cameraUrl);

                    req.AllowWriteStreamBuffering = true;
                    req.Timeout = 20000;

                    res = req.GetResponse();
                    stream = res.GetResponseStream();
                    pctViewer.Image = Image.FromStream(stream);
                    res.Close();
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception: {0}", e.ToString());
                }
            }
        }

        private void SendCommand(string commandUrl, string command, string optionalValue = "")
        {
            string url = "";
            if (!optionalValue.Equals("")) url = String.Format(commandUrl, txtHost.Text, txtUsername.Text, txtPassword.Text, command, optionalValue);
            else url = String.Format(commandUrl, txtHost.Text, txtUsername.Text, txtPassword.Text, command);
            WebClient wc = new WebClient();
            wc.DownloadString(url);
        }
        #endregion
    }
}
